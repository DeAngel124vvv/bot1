<p align="center">
<img src="./src/assistant.jpg" width="140" height="140"/>
</p>
<p align="center">
<a href="#"><img title="NyanBot" src="https://img.shields.io/badge/🐬𝑵𝒚𝒂𝒏𝑩𝒐𝒕 | 🔥𝗦𝗮𝗺𝘂𝟯𝟯𝟬🔥 | Sᥲm ყ Pᥱrrყ🥀-black?colorA=%23ff0000&colorB=%23000000&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/Samu330"><img title="Author" src="https://img.shields.io/badge/author-Samu330-green?colorA=%00ff00style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="#"><img title="MAINTENED" src="https://img.shields.io/badge/MAINTENED-YES-blue?colorA=%23ff0000&colorB=%230000ff&style=for-the-badge"</a>
</p>
<p align="center">
<img src="https://www.crackingpro.com/uploads/team_VIP.gif" width="200" height="80"/>
</p>
<img src="https://i.imgur.com/n1zo2wL.gif" width="30" height="30"/> NyanBot🐬
</p>
<br />
    Clona este repositorio</h3><img src="https://raw.githubusercontent.com/othneildrew/Best-README-Template/master/images/logo.png" alt="Logo" width="20" height="20">
  </a>

```bash
> git clone https://github.com/Samu330/NyanBot
```

## Inicia la Instalacion:

```bash
> cd NyanBot
> bash install.sh
```

### Para correr el bot usa:
```bash
> npm start
```

